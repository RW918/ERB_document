/*
  Conditionals
  ---------------------------------
  Write a function to test if a provided number is negative or positive
  - if number is less than zero, return the word "negative"
  - if number is more or equal to zero, return the word "positive"
*/

function negativeOrPositive(number) {
  // Add your code here.
  
}

/* 
  DO NOT EDIT BELOW THIS LINE
  --------------------------- */
const number1 = 5;
const number2 = -1;
const number3 = 0;

console.log(number1 + " is " + negativeOrPositive(number1));
console.log(number2 + " is " + negativeOrPositive(number2));
console.log(number3 + " is " + negativeOrPositive(number3));

/* 
  Expected Output
  ---------------
  5 is positive
  -1 is negative
  0 is positive
*/
