// Write a function that takes a name (a string) and returns a greeting

// Write your function here

function createGreeting(inputName) {

}

const greeting = createGreeting("Daniel");

console.log(greeting);

// Expected Output:
// Hello, my name is Daniel
