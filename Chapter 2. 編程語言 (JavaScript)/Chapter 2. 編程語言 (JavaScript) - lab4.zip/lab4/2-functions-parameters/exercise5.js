// Write a function that takes a name (a string) and an age (a number) and returns a greeting (a string)

// Write your code here
// Declare your function here

function createLongGreeting(inputName, age) {

}

const greeting = createLongGreeting("Daniel", 30);

console.log(greeting);

// Expected Output
// Hello, my name is Daniel and I'm 30 years old
