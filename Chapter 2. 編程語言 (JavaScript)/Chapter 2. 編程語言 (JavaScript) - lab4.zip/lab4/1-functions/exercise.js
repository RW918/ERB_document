// Please complete the halve function that it would return half of the input number (i.e. divide by 2)

function halve(number) {
  // complete the function here

}

const result = halve(12);

console.log(result);

// Expected result
// 6
