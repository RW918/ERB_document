// Please complete the halve function that it would return triple of input number (i.e. multiply by 3)


function triple(number) {
  // complete function here

}

const result = triple(12);

console.log(result);

// Expected result
// 36
