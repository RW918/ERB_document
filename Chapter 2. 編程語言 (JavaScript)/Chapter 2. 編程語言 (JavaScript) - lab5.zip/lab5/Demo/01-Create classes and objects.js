// Create a class and create a star class
class Star {
	constructor(uname, age) {
		this.uname = uname;
		this.age = age;
	}
}

// 2. Create an object new using a class
var ldh = new Star('Andy Lau', 18);
var zxy = new Star('Jacky Cheung', 20);
console.log(ldh);
console.log(zxy);
//(1) Creating classes using the class keyword, we still habitually define class names with uppercase letters
//(2) There is a constructor function in the class that can accept passed parameters and return instance objects
//(3) The constructor function will be automatically called whenever a new instance is generated. If we do not write this function, the class will also automatically generate this function
//(4) Generating instance new cannot be omitted
//(5) Finally, pay attention to syntax conventions, do not add parentheses after creating class names, add parentheses after generating instance class names, and do not add functions to constructors