// Create a class and create a star class
class Star {
	// Put the common properties of the class into the constructor
	constructor(uname, age) {
		this.uname = uname;
		this.age = age;
	}
	sing(song) {
	  
		console.log(this.uname + song);

	}
}

// 2. Create an object new using a class
var ldh = new Star('Andy Lau', 18);
var zxy = new Star('Jacky Cheung', 20);
console.log(ldh);
console.log(zxy);
//All functions in our class do not need to be written as functions
//Multiple function methods do not need to be separated by commas
ldh.sing('Ice rain');
zxy.sing('Li Xianglan');