//Task: Define a Person class.
//Private attributes: firstName (string type) and lastName (string type).



class Person {  
 
	// Task: Define private fields
	// your code here
    
	
    constructor(firstName, lastName) {  
		// Task: Initialize private fields firstName and lastName
		// your code here
        
    }  
 
	
    greet() {    
        console.log("Hello, my name is " + this.#_firstName + " " + this.#_lastName);  
    }  
}  
  
  
// test
const person = new Person('John', 'Doe');  
person.greet(); // Output："Hello, my name is John Doe."


  
// Expected Output
// Hello, my name is John Doe.



